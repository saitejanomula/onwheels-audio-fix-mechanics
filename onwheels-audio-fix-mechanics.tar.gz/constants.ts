
export const ADMIN_EMAIL = "amithagoudv@gmail.com";
export const ADMIN_PASSWORD = "Amithav@33";
export const DEFAULT_RADIUS_KM = 10;
export const DB_KEY_PREFIX = 'onwheels_core_v1';

export const COLORS = {
  primary: '#3b82f6', // blue-500
  secondary: '#10b981', // emerald-500
  accent: '#f59e0b', // amber-500
  danger: '#ef4444', // red-500
  background: '#020617' // slate-950
};
