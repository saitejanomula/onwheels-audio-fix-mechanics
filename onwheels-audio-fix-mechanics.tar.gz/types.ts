
export enum UserRole {
  USER = 'USER',
  MECHANIC = 'MECHANIC',
  ADMIN = 'ADMIN'
}

export type MechanicStatus = 'online' | 'offline' | 'busy';
export type BookingStatus = 'pending' | 'accepted' | 'declined' | 'completed' | 'timeout';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: UserRole;
  phone: string;
}

export interface FileData {
  base64: string;
  mimeType: string;
}

export interface MechanicRecord {
  mechanicId: string;
  userId: string;
  name: string;
  shopName: string;
  contact: string;
  city: string;
  area: string;
  lat: number;
  lng: number;
  licenseNumber: string;
  isVerified: boolean;
  isEnabled?: boolean; // Admin can enable/disable
  status: MechanicStatus;
  specialization: string;
  joinedAt: string;
  verifiedAt?: string; // When verified
  lastLocationUpdate?: string; // Real-time location timestamp
  distance?: number;
  documents?: string[]; // KYC document references
  rejectionReason?: string; // If rejected
}

export interface InspectionResult {
  vehicleType: string;
  faultName: string;
  urgency: 'Low' | 'Medium' | 'High' | 'Critical';
  repairEstimate: {
    min: number;
    max: number;
    recommendation: string;
  };
}

export interface Booking {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  mechanicId: string;
  status: BookingStatus;
  timestamp: number;
  userLocation: string;
  problemSummary: string;
  estimatedCost: string;
  vehicleType: string;
  lat: number;
  lng: number;
  diagnosticDetail?: InspectionResult;
  media?: {
    img?: FileData;
    aud?: FileData;
  };
}
