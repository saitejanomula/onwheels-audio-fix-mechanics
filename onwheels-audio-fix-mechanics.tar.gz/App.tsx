
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Zap, 
  History as HistoryIcon, 
  User as UserIcon, 
  Camera, 
  Mic, 
  LogOut, 
  Clock, 
  Phone, 
  Database, 
  ShieldAlert, 
  Activity,
  ChevronRight,
  ShieldCheck,
  Bell,
  Navigation as NavIcon,
  Trash2,
  Loader2,
  Shield
} from 'lucide-react';
import { 
  UserAccount, 
  MechanicRecord, 
  Booking, 
  InspectionResult, 
  FileData, 
  UserRole,
  BookingStatus 
} from './types';
import { 
  ADMIN_EMAIL, 
  ADMIN_PASSWORD, 
  DB_KEY_PREFIX, 
  DEFAULT_RADIUS_KM 
} from './constants';
import { runForensicAudit } from './services/diagnosticEngine';
import { DatabaseService, DB } from './services/database';

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371;
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
};

// --- Main App Component ---
const App: React.FC = () => {
  const [session, setSession] = useState<UserAccount | null>(() => {
    const s = localStorage.getItem('ow_active_session');
    return s ? JSON.parse(s) : null;
  });
  const [view, setView] = useState<'HOME' | 'LOGS' | 'PROFILE'>('HOME');
  const [loading, setLoading] = useState(false);
  const [userLoc, setUserLoc] = useState<{lat: number, lng: number} | null>(null);
  
  // Persistence for Diagnostic results
  const [diag, setDiag] = useState<InspectionResult | null>(null);
  const [files, setFiles] = useState<{img?: FileData, aud?: FileData}>({});
  
  // Real-time DB listeners
  const [mechanics, setMechanics] = useState<MechanicRecord[]>(DB.getMechanics());
  const [bookings, setBookings] = useState<Booking[]>(DB.getBookings());

  useEffect(() => {
    localStorage.setItem('ow_active_session', JSON.stringify(session));
  }, [session]);

  useEffect(() => {
    const sync = () => {
      setMechanics(DB.getMechanics());
      setBookings(DB.getBookings());
    };
    window.addEventListener('sync_db', sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener('sync_db', sync);
      window.removeEventListener('storage', sync);
    };
  }, []);

  // Real-time location tracking with database logging
  useEffect(() => {
    if (!navigator.geolocation) return;
    const watchId = navigator.geolocation.watchPosition(
      (p) => {
        const newLoc = { lat: p.coords.latitude, lng: p.coords.longitude };
        setUserLoc(newLoc);
        
        // Update mechanic location in real-time if logged in as mechanic
        if (session && session.role === UserRole.MECHANIC) {
          const mechanicRecord = DatabaseService.getMechanicByUserId(session.id);
          if (mechanicRecord) {
            DatabaseService.updateMechanicLocation(mechanicRecord.mechanicId, newLoc.lat, newLoc.lng);
          }
        }
        
        // Log user location periodically (every 5 minutes)
        if (session) {
          const lastLog = localStorage.getItem('last_location_log');
          const now = Date.now();
          if (!lastLog || now - parseInt(lastLog) > 5 * 60 * 1000) {
            DatabaseService.logLocation(session.id, newLoc.lat, newLoc.lng, 'position_update');
            localStorage.setItem('last_location_log', now.toString());
          }
        }
      },
      (error) => console.warn('Geolocation error:', error),
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 5000 }
    );
    return () => navigator.geolocation.clearWatch(watchId);
  }, [session]);

  // Session validation - logout deleted users
  useEffect(() => {
    if (!session) return;
    
    if (session.role === UserRole.ADMIN) return;
    
    const users = DB.getUsers();
    const userExists = users.find(u => u.id === session.id);
    
    if (!userExists) {
      console.log('User account no longer exists, logging out...');
      localStorage.removeItem('ow_active_session');
      setSession(null);
      alert('Your account has been removed from the system. Please contact support if this is an error.');
      return;
    }
    
    if (session.role === UserRole.MECHANIC) {
      const mechanicRecord = DatabaseService.getMechanicByUserId(session.id);
      if (!mechanicRecord) {
        console.log('Mechanic record no longer exists, logging out...');
        localStorage.removeItem('ow_active_session');
        setSession(null);
        alert('Your mechanic profile has been removed. Please contact admin for assistance.');
      }
    }
  }, [mechanics, session]);

  const handleLogout = () => {
    localStorage.removeItem('ow_active_session');
    setSession(null);
    setDiag(null);
    setFiles({});
    setView('HOME');
  };

  // --- Auth View ---
  const AuthView = () => {
    const [loginType, setLoginType] = useState<'user' | 'mechanic' | 'admin'>('user');
    const [isRegistering, setIsRegistering] = useState(false);
    const [form, setForm] = useState({
      name: '', email: '', password: '', role: UserRole.USER, phone: '',
      shop: '', specialization: 'General Service', license: ''
    });

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      
      // Admin login
      if (loginType === 'admin') {
        if (form.email.toLowerCase() === ADMIN_EMAIL.toLowerCase() && form.password === ADMIN_PASSWORD) {
          const adminUser: UserAccount = {
            id: 'admin-01',
            name: 'OnWheels Admin',
            email: ADMIN_EMAIL,
            role: UserRole.ADMIN,
            phone: '9666074478'
          };
          setSession(adminUser);
        } else {
          alert("Invalid admin credentials.");
        }
        return;
      }
      
      // User/Mechanic registration or login
      if (isRegistering) {
        const newUser: UserAccount = {
          id: `usr-${Date.now()}`,
          name: form.name,
          email: form.email,
          password: form.password,
          role: loginType === 'mechanic' ? UserRole.MECHANIC : UserRole.USER,
          phone: form.phone
        };
        DB.saveUser(newUser);
        
        if (loginType === 'mechanic') {
          const mRec: MechanicRecord = {
            mechanicId: `mech-${Date.now()}`,
            userId: newUser.id,
            name: form.name,
            shopName: form.shop,
            contact: form.phone,
            city: 'Active Hub',
            area: 'Local',
            lat: userLoc?.lat || 17.3850,
            lng: userLoc?.lng || 78.4867,
            licenseNumber: form.license,
            isVerified: false,
            isEnabled: true,
            status: 'online',
            specialization: form.specialization,
            joinedAt: new Date().toISOString()
          };
          DB.setMechanics([...DB.getMechanics(), mRec]);
        }
        setSession(newUser);
      } else {
        const valid = DB.validate(form.email, form.password);
        if (valid) {
          // Check role matches login type
          if (loginType === 'user' && valid.role === UserRole.USER) {
            setSession(valid);
          } else if (loginType === 'mechanic' && valid.role === UserRole.MECHANIC) {
            setSession(valid);
          } else {
            alert("Please use the correct login section for your account type.");
          }
        } else {
          alert("Invalid credentials provided.");
        }
      }
    };

    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-[60vh] bg-blue-600/10 blur-[150px]" />
        
        <div className="text-center mb-8 relative z-10">
          <div className="inline-flex p-6 bg-blue-600 rounded-[2.5rem] shadow-2xl shadow-blue-500/30 mb-6">
            <Zap className="text-white fill-white" size={48} />
          </div>
          <h1 className="text-6xl font-black italic tracking-tighter text-white mb-2">OnWheels</h1>
          <p className="text-[10px] uppercase font-bold tracking-[0.6em] text-slate-500">Forensic Automotive Intelligence</p>
        </div>

        {/* Login Type Tabs */}
        <div className="w-full max-w-sm mb-6 relative z-10">
          <div className="glass-card p-2 rounded-[2rem] flex gap-2">
            <button
              onClick={() => { setLoginType('user'); setIsRegistering(false); }}
              className={`flex-1 py-4 rounded-[1.5rem] text-[11px] font-black uppercase tracking-wider transition-all ${
                loginType === 'user'
                  ? 'bg-blue-600 text-white shadow-lg'
                  : 'text-slate-500 hover:text-white'
              }`}
            >
              👤 User
            </button>
            <button
              onClick={() => { setLoginType('mechanic'); setIsRegistering(false); }}
              className={`flex-1 py-4 rounded-[1.5rem] text-[11px] font-black uppercase tracking-wider transition-all ${
                loginType === 'mechanic'
                  ? 'bg-emerald-600 text-white shadow-lg'
                  : 'text-slate-500 hover:text-white'
              }`}
            >
              🔧 Mechanic
            </button>
            <button
              onClick={() => { setLoginType('admin'); setIsRegistering(false); }}
              className={`flex-1 py-4 rounded-[1.5rem] text-[11px] font-black uppercase tracking-wider transition-all ${
                loginType === 'admin'
                  ? 'bg-red-600 text-white shadow-lg'
                  : 'text-slate-500 hover:text-white'
              }`}
            >
              🛡️ Admin
            </button>
          </div>
        </div>

        {/* Login Form */}
        <div className="w-full max-w-sm glass-card p-10 rounded-[3.5rem] relative z-10 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="text-center mb-6">
              <h3 className="text-2xl font-black uppercase text-white mb-1">
                {loginType === 'admin' ? '🛡️ Admin Access' :
                 loginType === 'mechanic' ? '🔧 Mechanic Portal' :
                 '👤 User Login'}
              </h3>
              <p className="text-[9px] text-slate-600 uppercase tracking-widest">
                {isRegistering ? 'Create Account' : 'Authenticate'}
              </p>
            </div>
            
            {/* Registration fields for User/Mechanic */}
            {isRegistering && loginType !== 'admin' && (
              <input 
                required 
                placeholder="Full Name" 
                className="w-full bg-slate-900 border border-white/5 p-5 rounded-3xl text-white font-medium focus:border-blue-500 outline-none transition-all" 
                value={form.name} 
                onChange={e => setForm({...form, name: e.target.value})} 
              />
            )}
            
            {/* Email & Password for all */}
            <input 
              required 
              type="email" 
              placeholder={loginType === 'admin' ? 'Admin Email' : 'Email Address'} 
              className="w-full bg-slate-900 border border-white/5 p-5 rounded-3xl text-white font-medium focus:border-blue-500 outline-none transition-all" 
              value={form.email} 
              onChange={e => setForm({...form, email: e.target.value})} 
            />
            <input 
              required 
              type="password" 
              placeholder="Password" 
              className="w-full bg-slate-900 border border-white/5 p-5 rounded-3xl text-white font-medium focus:border-blue-500 outline-none transition-all" 
              value={form.password} 
              onChange={e => setForm({...form, password: e.target.value})} 
            />
            
            {/* Additional fields for registration */}
            {isRegistering && loginType !== 'admin' && (
              <>
                <input 
                  required 
                  placeholder="Phone Number" 
                  className="w-full bg-slate-900 border border-white/5 p-5 rounded-3xl text-white font-medium outline-none" 
                  value={form.phone} 
                  onChange={e => setForm({...form, phone: e.target.value})} 
                />
                
                {loginType === 'mechanic' && (
                  <div className="space-y-4 pt-2 border-t border-white/5">
                    <input 
                      required 
                      placeholder="Workshop Name" 
                      className="w-full bg-slate-800 p-5 rounded-3xl text-white outline-none" 
                      value={form.shop} 
                      onChange={e => setForm({...form, shop: e.target.value})} 
                    />
                    <select 
                      className="w-full bg-slate-800 p-5 rounded-3xl text-white outline-none" 
                      value={form.specialization} 
                      onChange={e => setForm({...form, specialization: e.target.value})}
                    >
                      <option>General Service</option>
                      <option>Engine & Transmission</option>
                      <option>Electric (EV)</option>
                      <option>Electrical & Diagnostics</option>
                    </select>
                    <input 
                      placeholder="License Number (Optional)" 
                      className="w-full bg-slate-800 p-5 rounded-3xl text-white outline-none" 
                      value={form.license} 
                      onChange={e => setForm({...form, license: e.target.value})} 
                    />
                  </div>
                )}
              </>
            )}

            {/* Admin login hint */}
            {loginType === 'admin' && !isRegistering && (
              <div className="bg-red-900/20 border border-red-500/30 rounded-2xl p-4">
                <p className="text-[10px] text-red-400 text-center uppercase tracking-wider">
                  ⚠️ Authorized Personnel Only
                </p>
              </div>
            )}

            {/* Submit Button */}
            <button 
              type="submit" 
              className={`w-full py-6 rounded-[2.5rem] font-black uppercase tracking-[0.3em] shadow-xl hover:opacity-90 active:scale-95 transition-all mt-4 ${
                loginType === 'admin' ? 'bg-red-600' :
                loginType === 'mechanic' ? 'bg-emerald-600' :
                'bg-blue-600'
              } text-white`}
            >
              {isRegistering ? 'Create Account' : 'Sign In'}
            </button>
          </form>
          
          {/* Register Toggle (only for User/Mechanic) */}
          {loginType !== 'admin' && (
            <button 
              onClick={() => setIsRegistering(!isRegistering)} 
              className="w-full text-center mt-6 text-[10px] font-bold uppercase tracking-widest text-slate-600 hover:text-white transition-colors"
            >
              {isRegistering ? '← Back to Login' : 'New here? Register →'}
            </button>
          )}
          
          {/* Admin credentials hint (for demo/testing) */}
          {loginType === 'admin' && (
            <div className="mt-6 text-center">
              <p className="text-[8px] text-slate-700 uppercase tracking-wider">
                Admin credentials required
              </p>
            </div>
          )}
        </div>
      </div>
    );
  };

  // --- User Dashboard ---
  const UserPanel = () => {
    const nearbyMechs = useMemo(() => {
      if (!userLoc) return [];
      return mechanics
        .filter(m => m.isVerified && (m as any).isEnabled !== false) // Show verified and not disabled
        .map(m => ({
          ...m,
          distance: parseFloat(calculateDistance(userLoc.lat, userLoc.lng, m.lat, m.lng).toFixed(2))
        }))
        .filter(m => (m.distance || 0) < DEFAULT_RADIUS_KM)
        .sort((a, b) => (a.distance || 0) - (b.distance || 0));
    }, [userLoc, mechanics]);

    const activeReq = useMemo(() => {
      return bookings.find(b => b.userId === session?.id && (b.status === 'pending' || b.status === 'accepted'));
    }, [bookings, session]);

    const handleFile = (e: React.ChangeEvent<HTMLInputElement>, type: 'img' | 'aud') => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const base64 = (ev.target?.result as string).split(',')[1];
        setFiles(prev => ({ ...prev, [type]: { base64, mimeType: file.type } }));
      };
      reader.readAsDataURL(file);
    };

    const runDiagnostic = async () => {
      if (!files.img && !files.aud) return alert("Upload visual or acoustic evidence first.");
      setLoading(true);
      try {
        const result = await runForensicAudit(files.img, files.aud);
        setDiag(result);
      } catch (err: any) {
        alert(err.message || "Forensic audit failed. Check network connectivity.");
      } finally {
        setLoading(false);
      }
    };

    const requestRescue = (mech: MechanicRecord) => {
      const newBooking: Booking = {
        id: `book-${Date.now()}`,
        userId: session!.id,
        userName: session!.name,
        userPhone: session!.phone,
        mechanicId: mech.mechanicId,
        status: 'pending',
        timestamp: Date.now(),
        userLocation: "Current Coordinates",
        problemSummary: diag?.faultName || "Emergency SOS - Unspecified Fault",
        estimatedCost: diag ? `₹${diag.repairEstimate.min}-${diag.repairEstimate.max}` : "Consultation Pending",
        vehicleType: diag?.vehicleType || "General",
        lat: userLoc?.lat || 0,
        lng: userLoc?.lng || 0,
        diagnosticDetail: diag || undefined,
        media: files
      };
      DB.setBookings([...bookings, newBooking]);
      window.location.href = `tel:${mech.contact}`;
    };

    return (
      <div className="space-y-10 pb-32 animate-in fade-in duration-500">
        {activeReq ? (
          <div className="glass-card p-10 rounded-[3.5rem] border-blue-500/20 bg-blue-600/5 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-8">
              <Activity className="text-blue-500 animate-pulse" size={32} />
            </div>
            <p className="text-[10px] font-black uppercase text-blue-500 tracking-[0.3em] mb-4">Rescue Node Active</p>
            <h2 className="text-3xl font-black italic text-white uppercase tracking-tighter mb-4">
              {activeReq.status === 'pending' ? 'Broadcasting SOS' : 'Specialist Dispatched'}
            </h2>
            <div className="flex items-center gap-4 bg-slate-900/80 p-6 rounded-3xl border border-white/5">
              <div className="w-12 h-12 bg-blue-600 rounded-2xl flex items-center justify-center text-white font-bold text-xl">
                {mechanics.find(m => m.mechanicId === activeReq.mechanicId)?.shopName[0]}
              </div>
              <div>
                <p className="font-bold text-white">{mechanics.find(m => m.mechanicId === activeReq.mechanicId)?.shopName}</p>
                <p className="text-xs text-slate-500">{activeReq.status.toUpperCase()}</p>
              </div>
              <a href={`tel:${mechanics.find(m => m.mechanicId === activeReq.mechanicId)?.contact}`} className="ml-auto p-4 bg-emerald-600 rounded-2xl text-white shadow-lg shadow-emerald-500/20">
                <Phone size={20} />
              </a>
            </div>
          </div>
        ) : (
          <>
            <div className="glass-card p-10 rounded-[4rem] relative overflow-hidden group">
              <div className="scanner-line absolute top-0 left-0 w-full" />
              <h2 className="text-5xl font-black italic tracking-tighter text-white mb-2">Forensic<br/>Audit</h2>
              <p className="text-[11px] font-bold text-blue-500 uppercase tracking-widest mb-8">Advanced Vehicle Scanning</p>
              
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div onClick={() => document.getElementById('cam-in')?.click()} className={`aspect-square glass-card rounded-[3rem] flex flex-col items-center justify-center gap-4 transition-all cursor-pointer ${files.img ? 'bg-blue-600/10 border-blue-500' : 'hover:border-white/20'}`}>
                  <Camera size={32} className={files.img ? 'text-blue-500' : 'text-slate-600'} />
                  <p className="text-[10px] font-black uppercase tracking-widest">{files.img ? 'Ready' : 'Capture'}</p>
                  <input type="file" id="cam-in" hidden accept="image/*" onChange={e => handleFile(e, 'img')} />
                </div>
                <div onClick={() => document.getElementById('mic-in')?.click()} className={`aspect-square glass-card rounded-[3rem] flex flex-col items-center justify-center gap-4 transition-all cursor-pointer ${files.aud ? 'bg-emerald-600/10 border-emerald-500' : 'hover:border-white/20'}`}>
                  <Mic size={32} className={files.aud ? 'text-emerald-500' : 'text-slate-600'} />
                  <p className="text-[10px] font-black uppercase tracking-widest">{files.aud ? 'Recorded' : 'Record'}</p>
                  <input type="file" id="mic-in" hidden accept="audio/*" onChange={e => handleFile(e, 'aud')} />
                </div>
              </div>

              <button disabled={loading} onClick={runDiagnostic} className="w-full py-7 bg-blue-600 text-white rounded-[3rem] font-black uppercase tracking-[0.3em] flex items-center justify-center gap-3 shadow-2xl active:scale-95 transition-all">
                {loading ? <Loader2 className="animate-spin" /> : <Zap size={20} />}
                {loading ? 'Running Diagnostics' : 'Start Diagnostic Scan'}
              </button>
            </div>

            {diag && (
              <div className="glass-card p-10 rounded-[3.5rem] border-white/10 animate-in slide-in-from-bottom-10 shadow-2xl">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-1">Asset Detected</p>
                    <h3 className="text-2xl font-black italic text-white uppercase tracking-tighter">{diag.vehicleType}</h3>
                  </div>
                  <div className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${
                    diag.urgency === 'Critical' ? 'bg-red-600 text-white animate-pulse' : 'bg-blue-600/20 text-blue-500'
                  }`}>
                    {diag.urgency}
                  </div>
                </div>

                <div className="bg-slate-900/50 p-6 rounded-[2.5rem] border border-white/5 mb-8">
                  <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-2">Fault Diagnosis</p>
                  <p className="text-lg font-bold text-white italic">"{diag.faultName}"</p>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-10">
                  <div className="p-6 bg-slate-900 rounded-3xl text-center">
                    <p className="text-2xl font-black text-white">₹{diag.repairEstimate.min}</p>
                    <p className="text-[9px] font-bold text-slate-600 uppercase">Min Est</p>
                  </div>
                  <div className="p-6 bg-slate-900 rounded-3xl text-center">
                    <p className="text-2xl font-black text-white">₹{diag.repairEstimate.max}</p>
                    <p className="text-[9px] font-bold text-slate-600 uppercase">Max Est</p>
                  </div>
                </div>

                <h4 className="text-xl font-black italic text-white uppercase tracking-tighter mb-6">Nearby Specialists</h4>
                <div className="space-y-4">
                  {nearbyMechs.length === 0 ? (
                    <p className="text-center py-10 text-slate-700 text-[10px] font-black uppercase tracking-widest">No verified specialists in range</p>
                  ) : nearbyMechs.map(m => (
                    <div key={m.mechanicId} className="p-8 glass-card rounded-[2.5rem] border-white/5 hover:border-blue-500/30 transition-all flex items-center justify-between">
                      <div>
                        <p className="font-black text-white text-lg tracking-tight mb-1">{m.shopName}</p>
                        <p className="text-[9px] font-bold text-slate-500 uppercase tracking-widest">{m.specialization} • {m.distance}km</p>
                      </div>
                      <button onClick={() => requestRescue(m)} className="p-4 bg-emerald-600 rounded-2xl text-white shadow-xl hover:bg-emerald-500 transition-all">
                        <NavIcon size={20} fill="white" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    );
  };

  // --- Mechanic Dashboard ---
  const MechanicPanel = () => {
    const record = useMemo(() => mechanics.find(m => m.userId === session?.id), [mechanics, session]);
    const incomingReqs = useMemo(() => 
      bookings.filter(b => b.mechanicId === record?.mechanicId && (b.status === 'pending' || b.status === 'accepted')),
    [bookings, record]);

    if (!record?.isVerified) {
      return (
        <div className="h-[60vh] flex flex-col items-center justify-center p-12 text-center">
          <div className="p-8 bg-amber-500/10 rounded-[3rem] border border-amber-500/20 mb-8">
            <ShieldAlert className="text-amber-500" size={64} />
          </div>
          <h2 className="text-3xl font-black italic text-white uppercase tracking-tighter mb-4">Awaiting Authorization</h2>
          <p className="text-sm font-medium text-slate-500 leading-relaxed">Verification of your terminal is required before accepting SOS beacons. Contact Command Hub.</p>
        </div>
      );
    }

    const updateBooking = (id: string, status: BookingStatus) => {
      DB.setBookings(bookings.map(b => b.id === id ? { ...b, status } : b));
    };

    return (
      <div className="space-y-10 pb-32 animate-in fade-in duration-500">
        <div className="flex justify-between items-center">
          <h2 className="text-4xl font-black italic text-white uppercase tracking-tighter">Terminal Hub</h2>
          <div className="flex items-center gap-2 px-4 py-2 bg-emerald-600/10 border border-emerald-500/30 rounded-full">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">Online</span>
          </div>
        </div>

        <div className="space-y-6">
          <p className="text-[10px] font-black text-slate-600 uppercase tracking-[0.4em] px-2">Live SOS Beacons</p>
          {incomingReqs.length === 0 ? (
            <div className="py-32 text-center border-2 border-dashed border-white/5 rounded-[4rem]">
              <p className="text-slate-700 text-[10px] font-black uppercase tracking-widest">Scanning for distress signals...</p>
            </div>
          ) : incomingReqs.map(req => (
            <div key={req.id} className={`glass-card p-12 rounded-[4rem] border-2 shadow-2xl transition-all ${req.status === 'accepted' ? 'border-emerald-500/40 bg-emerald-500/5' : 'border-blue-600/30 animate-in zoom-in-95'}`}>
              <div className="flex justify-between items-start mb-8">
                <div className="flex items-center gap-4">
                  <div className={`p-4 rounded-2xl ${req.status === 'accepted' ? 'bg-emerald-600' : 'bg-blue-600 animate-bounce'}`}>
                    <Bell className="text-white fill-white" size={24} />
                  </div>
                  <div>
                    <h3 className="text-2xl font-black italic text-white uppercase tracking-tighter">{req.userName}</h3>
                    <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">{req.vehicleType}</p>
                  </div>
                </div>
                {req.status === 'accepted' && (
                  <a href={`tel:${req.userPhone}`} className="p-5 bg-slate-900 rounded-3xl text-white">
                    <Phone size={24} />
                  </a>
                )}
              </div>

              <div className="p-8 bg-slate-950/80 rounded-[2.5rem] border border-white/5 mb-10">
                <p className="text-[9px] font-black text-slate-500 uppercase tracking-widest mb-3">Diagnostic Summary</p>
                <p className="text-lg font-bold text-white italic mb-2">"{req.problemSummary}"</p>
                <p className="text-sm font-bold text-emerald-500 uppercase tracking-tighter">Budget: {req.estimatedCost}</p>
              </div>

              {req.status === 'pending' ? (
                <div className="grid grid-cols-2 gap-4">
                  <button onClick={() => updateBooking(req.id, 'accepted')} className="py-7 bg-emerald-600 text-white rounded-[2.5rem] font-black uppercase text-xs tracking-widest shadow-xl">Respond</button>
                  <button onClick={() => updateBooking(req.id, 'declined')} className="py-7 bg-slate-900 text-slate-600 rounded-[2.5rem] font-black uppercase text-xs tracking-widest">Decline</button>
                </div>
              ) : (
                <button onClick={() => updateBooking(req.id, 'completed')} className="w-full py-7 bg-white text-slate-950 rounded-[2.5rem] font-black uppercase text-xs tracking-[0.4em] shadow-2xl active:scale-95 transition-all">Mission Complete</button>
              )}
            </div>
          ))}
        </div>
      </div>
    );
  };

  // --- Admin Hub ---
  const AdminPanel = () => {
    const [activeTab, setActiveTab] = useState<'dashboard' | 'mechanics' | 'bookings' | 'users'>('dashboard');
    const [showAddMechanic, setShowAddMechanic] = useState(false);
    const [newMechanicForm, setNewMechanicForm] = useState({
      name: '', shopName: '', email: '', password: '', phone: '',
      specialization: 'General Service', license: '', city: '', area: ''
    });
    
    const pending = mechanics.filter(m => !m.isVerified);
    const verified = mechanics.filter(m => m.isVerified);
    const disabled = mechanics.filter(m => (m as any).isEnabled === false);
    const allUsers = DB.getUsers();

    const handleAddMechanic = (e: React.FormEvent) => {
      e.preventDefault();
      const newUser: UserAccount = {
        id: `usr-${Date.now()}`,
        name: newMechanicForm.name,
        email: newMechanicForm.email,
        password: newMechanicForm.password,
        role: UserRole.MECHANIC,
        phone: newMechanicForm.phone
      };
      DB.saveUser(newUser);
      const newMechanic: MechanicRecord = {
        mechanicId: `mech-${Date.now()}`,
        userId: newUser.id,
        name: newMechanicForm.name,
        shopName: newMechanicForm.shopName,
        contact: newMechanicForm.phone,
        city: newMechanicForm.city || 'City',
        area: newMechanicForm.area || 'Area',
        lat: userLoc?.lat || 17.3850,
        lng: userLoc?.lng || 78.4867,
        licenseNumber: newMechanicForm.license,
        isVerified: false,
        isEnabled: true,
        status: 'offline',
        specialization: newMechanicForm.specialization,
        joinedAt: new Date().toISOString()
      };
      DatabaseService.addMechanic(newMechanic);
      setShowAddMechanic(false);
      setNewMechanicForm({ name: '', shopName: '', email: '', password: '', phone: '', specialization: 'General Service', license: '', city: '', area: '' });
      alert(`Mechanic ${newMechanicForm.name} added!`);
    };

    const handleVerifyMechanic = (mechanicId: string) => {
      if (confirm('Verify this mechanic?')) DatabaseService.updateMechanicVerification(mechanicId, true);
    };

    const handleRejectMechanic = (mechanic: MechanicRecord) => {
      const reason = prompt('Rejection reason:');
      if (reason) {
        DB.setMechanics(mechanics.map(m => m.mechanicId === mechanic.mechanicId ? { ...m, rejectionReason: reason } : m));
      }
    };

    const handleToggleEnabled = (mechanicId: string, currentStatus: boolean) => {
      if (confirm(`${currentStatus === false ? 'Enable' : 'Disable'} this mechanic?`)) {
        DB.setMechanics(mechanics.map(m => m.mechanicId === mechanicId ? { ...m, isEnabled: currentStatus === false } : m));
      }
    };

    const handleDeleteMechanic = (mechanic: MechanicRecord) => {
      if (confirm(`DELETE ${mechanic.shopName}? This cannot be undone!`)) {
        DatabaseService.deleteMechanic(mechanic.mechanicId);
      }
    };

    return (
      <div className="space-y-6 pb-32">
        <div className="flex items-center justify-between">
          <div><h2 className="text-3xl font-black text-white uppercase">Admin Panel</h2><p className="text-[8px] text-slate-600 uppercase">Real-time control</p></div>
          <button onClick={() => setShowAddMechanic(true)} className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-[9px] font-black uppercase">+ Add</button>
        </div>

        {showAddMechanic && (
          <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4">
            <div className="glass-card p-6 rounded-[2rem] max-w-md w-full max-h-[90vh] overflow-auto">
              <h3 className="text-xl font-black text-white mb-4">Add Mechanic</h3>
              <form onSubmit={handleAddMechanic} className="space-y-2">
                <input required placeholder="Name" className="w-full bg-slate-900 p-3 rounded-xl text-white text-sm" value={newMechanicForm.name} onChange={e => setNewMechanicForm({...newMechanicForm, name: e.target.value})} />
                <input required placeholder="Shop" className="w-full bg-slate-900 p-3 rounded-xl text-white text-sm" value={newMechanicForm.shopName} onChange={e => setNewMechanicForm({...newMechanicForm, shopName: e.target.value})} />
                <input required type="email" placeholder="Email" className="w-full bg-slate-900 p-3 rounded-xl text-white text-sm" value={newMechanicForm.email} onChange={e => setNewMechanicForm({...newMechanicForm, email: e.target.value})} />
                <input required type="password" placeholder="Password" className="w-full bg-slate-900 p-3 rounded-xl text-white text-sm" value={newMechanicForm.password} onChange={e => setNewMechanicForm({...newMechanicForm, password: e.target.value})} />
                <input required placeholder="Phone" className="w-full bg-slate-900 p-3 rounded-xl text-white text-sm" value={newMechanicForm.phone} onChange={e => setNewMechanicForm({...newMechanicForm, phone: e.target.value})} />
                <select className="w-full bg-slate-900 p-3 rounded-xl text-white text-sm" value={newMechanicForm.specialization} onChange={e => setNewMechanicForm({...newMechanicForm, specialization: e.target.value})}>
                  <option>General Service</option>
                  <option>Engine & Transmission</option>
                  <option>Electric (EV)</option>
                  <option>Electrical & Diagnostics</option>
                </select>
                <div className="flex gap-2 pt-2">
                  <button type="button" onClick={() => setShowAddMechanic(false)} className="flex-1 py-2 bg-slate-800 text-white rounded-xl text-xs">Cancel</button>
                  <button type="submit" className="flex-1 py-2 bg-emerald-600 text-white rounded-xl text-xs">Add</button>
                </div>
              </form>
            </div>
          </div>
        )}

        <div className="flex gap-2">
          {[{id:'dashboard',l:'📊 Dashboard'},{id:'mechanics',l:'🔧 Mechanics'},{id:'bookings',l:'📋 Bookings'},{id:'users',l:'👥 Users'}].map(t=>(
            <button key={t.id} onClick={()=>setActiveTab(t.id as any)} className={`px-3 py-2 rounded-xl text-[9px] font-black uppercase ${activeTab===t.id?'bg-blue-600 text-white':'bg-slate-900 text-slate-500'}`}>{t.l}</button>
          ))}
        </div>

        {activeTab==='dashboard'&&(<div className="space-y-4"><div className="grid grid-cols-2 gap-3"><div className="glass-card p-4 rounded-xl text-center"><p className="text-3xl font-black text-emerald-500">{verified.length}</p><p className="text-[8px] text-slate-600 uppercase">Verified</p></div><div className="glass-card p-4 rounded-xl text-center"><p className="text-3xl font-black text-amber-500">{pending.length}</p><p className="text-[8px] text-slate-600 uppercase">Pending</p></div><div className="glass-card p-4 rounded-xl text-center"><p className="text-3xl font-black text-red-500">{disabled.length}</p><p className="text-[8px] text-slate-600 uppercase">Disabled</p></div><div className="glass-card p-4 rounded-xl text-center"><p className="text-3xl font-black text-blue-500">{allUsers.length}</p><p className="text-[8px] text-slate-600 uppercase">Users</p></div><div className="col-span-2 glass-card p-5 rounded-xl text-center"><p className="text-4xl font-black text-white">{bookings.length}</p><p className="text-[9px] text-slate-500 uppercase">Bookings</p></div></div></div>)}

        {activeTab==='mechanics'&&(<div className="space-y-4">{pending.length>0&&(<div><p className="text-[9px] font-black text-amber-500 uppercase mb-2">Pending ({pending.length})</p>{pending.map(m=>(<div key={m.mechanicId} className="glass-card p-4 rounded-xl"><div className="flex gap-2 mb-3"><div className="w-10 h-10 bg-amber-500/20 rounded-lg flex items-center justify-center text-amber-500 font-black">{m.shopName[0]}</div><div className="flex-1 min-w-0"><p className="text-sm font-black text-white truncate">{m.shopName}</p><p className="text-[8px] text-slate-500">{m.name}</p></div></div><div className="grid grid-cols-3 gap-1"><button onClick={()=>handleVerifyMechanic(m.mechanicId)} className="py-2 bg-emerald-600 text-white rounded-lg text-[8px]">✓</button><button onClick={()=>handleRejectMechanic(m)} className="py-2 bg-orange-600/20 text-orange-500 rounded-lg text-[8px]">✗</button><button onClick={()=>handleDeleteMechanic(m)} className="py-2 bg-red-600/20 text-red-500 rounded-lg text-[8px]">🗑</button></div></div>))}</div>)}<div><p className="text-[9px] font-black text-emerald-500 uppercase mb-2">Verified ({verified.length})</p>{verified.map(m=>{const isEnabled=(m as any).isEnabled!==false;const lastUpdate=(m as any).lastLocationUpdate;const isOnline=lastUpdate&&(Date.now()-new Date(lastUpdate).getTime()<5*60*1000);return(<div key={m.mechanicId} className="glass-card p-4 rounded-xl"><div className="flex gap-2 mb-3"><div className="relative"><div className="w-10 h-10 bg-emerald-500/20 rounded-lg flex items-center justify-center text-emerald-500 font-black">{m.shopName[0]}</div>{isOnline&&<div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full"></div>}</div><div className="flex-1 min-w-0"><div className="flex gap-1"><p className="text-sm font-black text-white truncate">{m.shopName}</p>{!isEnabled&&<span className="px-1 bg-red-600/20 text-red-500 text-[7px] rounded">OFF</span>}</div><p className="text-[8px] text-slate-500">{m.name}</p></div></div><div className="grid grid-cols-2 gap-1"><button onClick={()=>handleToggleEnabled(m.mechanicId,(m as any).isEnabled)} className={`py-2 rounded-lg text-[8px] ${isEnabled?'bg-orange-600/20 text-orange-500':'bg-emerald-600/20 text-emerald-500'}`}>{isEnabled?'⏸':'▶'}</button><button onClick={()=>handleDeleteMechanic(m)} className="py-2 bg-red-600/20 text-red-500 rounded-lg text-[8px]">🗑</button></div></div>)})}</div></div>)}

        {activeTab==='bookings'&&(<div className="space-y-3">{bookings.sort((a,b)=>b.timestamp-a.timestamp).map(b=>(<div key={b.id} className="glass-card p-4 rounded-xl"><div className="flex justify-between mb-1"><p className="text-sm font-black text-white">{b.userName}</p><span className={`px-2 py-0.5 rounded text-[7px] font-black uppercase ${b.status==='completed'?'bg-emerald-600/20 text-emerald-500':b.status==='accepted'?'bg-blue-600/20 text-blue-500':b.status==='declined'?'bg-red-600/20 text-red-500':'bg-amber-600/20 text-amber-500'}`}>{b.status}</span></div><p className="text-[8px] text-slate-600">{b.problemSummary}</p></div>))}</div>)}

        {activeTab==='users'&&(<div className="space-y-3">{allUsers.map(u=>(<div key={u.id} className="glass-card p-4 rounded-xl flex justify-between"><div><p className="text-sm font-black text-white">{u.name}</p><p className="text-[8px] text-slate-500">{u.email}</p></div><span className={`px-2 py-1 rounded text-[8px] font-black uppercase self-start ${u.role==='ADMIN'?'bg-red-600/20 text-red-500':u.role==='MECHANIC'?'bg-blue-600/20 text-blue-500':'bg-emerald-600/20 text-emerald-500'}`}>{u.role}</span></div>))}</div>)}
      </div>
    );
  };

  if (!session) return <AuthView />;

  return (
    <div className="max-w-md mx-auto min-h-screen bg-slate-950 flex flex-col relative overflow-hidden font-sans border-x border-white/5 shadow-2xl">
      {/* Decorative gradients */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[60vh] bg-blue-600/5 blur-[200px] pointer-events-none" />
      
      <header className="px-10 py-12 flex items-center justify-between z-50 sticky top-0 bg-slate-950/80 backdrop-blur-2xl border-b border-white/5">
        <div className="flex items-center gap-5 cursor-pointer" onClick={() => setView('HOME')}>
          <div className="bg-blue-600 p-4 rounded-3xl shadow-lg shadow-blue-500/30">
            <Zap className="text-white fill-white" size={20} />
          </div>
          <div>
            <h1 className="text-2xl font-black italic tracking-tighter text-white leading-none uppercase">OnWheels</h1>
            <p className="text-[9px] font-black text-slate-600 uppercase tracking-widest mt-1">{session.role} TERMINAL</p>
          </div>
        </div>
        <button onClick={handleLogout} className="p-5 rounded-2xl bg-slate-900 border border-white/10 text-slate-600 hover:text-red-500 transition-all active:scale-90">
          <LogOut size={22} />
        </button>
      </header>

      <main className="flex-1 px-8 pt-10 relative z-10">
        {view === 'HOME' && (
          session.role === UserRole.USER ? <UserPanel /> : 
          session.role === UserRole.MECHANIC ? <MechanicPanel /> : <AdminPanel />
        )}
        
        {view === 'LOGS' && (
          <div className="space-y-8 pb-32 animate-in fade-in duration-500">
            <h2 className="text-4xl font-black italic text-white uppercase tracking-tighter">Mission Log</h2>
            <div className="space-y-4">
              {bookings.filter(b => b.userId === session.id || b.mechanicId === session.id || session.role === UserRole.ADMIN).length === 0 ? (
                <p className="text-center py-20 text-slate-700 text-[10px] font-black uppercase tracking-widest">No mission history recorded</p>
              ) : bookings.filter(b => b.userId === session.id || b.mechanicId === session.id || session.role === UserRole.ADMIN).sort((a,b)=>b.timestamp-a.timestamp).map(b => (
                <div key={b.id} className="glass-card p-10 rounded-[3rem] border-white/5 shadow-xl transition-all hover:border-blue-500/20">
                  <div className="flex justify-between items-center mb-6">
                    <p className="font-black text-white uppercase text-lg italic tracking-tighter">
                      {mechanics.find(m => m.mechanicId === b.mechanicId)?.shopName || 'Rescue Node'}
                    </p>
                    <span className={`px-4 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${
                      b.status === 'completed' ? 'bg-emerald-600/10 text-emerald-500' : 'bg-slate-900 text-slate-500'
                    }`}>{b.status}</span>
                  </div>
                  <div className="flex items-center gap-2 text-slate-600">
                    <Clock size={12} />
                    <p className="text-[9px] uppercase font-bold tracking-widest">{new Date(b.timestamp).toLocaleString()}</p>
                  </div>
                  <p className="mt-4 text-[10px] text-slate-400 font-medium tracking-tight">MISSION ID: {b.id.toUpperCase()}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {view === 'PROFILE' && (
          <div className="flex flex-col items-center justify-center min-h-[70vh] pb-32 animate-in zoom-in-95 duration-500">
            <div className="relative mb-12">
              <div className="w-48 h-48 bg-gradient-to-br from-blue-700 to-slate-950 rounded-[4.5rem] flex items-center justify-center text-7xl font-black text-white shadow-2xl border-4 border-white/10 ring-8 ring-blue-600/5">
                {session.name[0]}
              </div>
              <div className="absolute -bottom-2 -right-2 p-5 bg-emerald-600 rounded-[2rem] border-4 border-slate-950 shadow-xl">
                <ShieldCheck className="text-white" size={28} />
              </div>
            </div>
            
            <h3 className="text-4xl font-black italic text-white uppercase text-center mb-4 tracking-tighter leading-none">{session.name}</h3>
            <div className="px-8 py-2 bg-blue-600/10 rounded-full border border-blue-500/20">
              <span className="text-[10px] text-blue-500 uppercase font-black tracking-[0.5em]">{session.role} CORE</span>
            </div>

            <div className="mt-12 w-full glass-card p-10 rounded-[3.5rem] border-white/5 space-y-6 shadow-2xl">
              <div className="flex justify-between items-center py-2 border-b border-white/5">
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Global Ident</p>
                <p className="text-[11px] font-bold text-white lowercase">{session.email}</p>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-white/5">
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Phone Sync</p>
                <p className="text-[11px] font-bold text-white uppercase tracking-tighter">{session.phone}</p>
              </div>
              <div className="flex justify-between items-center py-2">
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest">Security Status</p>
                <p className="text-[11px] font-black text-emerald-500 uppercase tracking-widest">Authenticated</p>
              </div>
            </div>
          </div>
        )}
      </main>

      <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-md bg-slate-950/98 backdrop-blur-3xl border-t border-white/5 px-16 pt-10 pb-12 flex justify-between items-center z-50 rounded-t-[5rem] shadow-[0_-10px_50px_rgba(0,0,0,0.6)]">
        {[
          { id: 'HOME', icon: session.role === UserRole.ADMIN ? Database : Zap, label: session.role === UserRole.ADMIN ? 'Command' : 'SOS' },
          { id: 'LOGS', icon: HistoryIcon, label: 'Logs' },
          { id: 'PROFILE', icon: UserIcon, label: 'Core' }
        ].map(item => (
          <button key={item.id} onClick={() => setView(item.id as any)} className={`flex flex-col items-center gap-3 transition-all duration-300 ${view === item.id ? 'text-blue-500 scale-110' : 'text-slate-700'}`}>
            <item.icon size={28} className={view === item.id ? 'fill-blue-500/10 drop-shadow-[0_0_12px_rgba(59,130,246,0.6)]' : ''} />
            <span className={`text-[9px] font-black uppercase tracking-widest transition-colors ${view === item.id ? 'text-white' : 'text-slate-800'}`}>{item.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
};

export default App;
