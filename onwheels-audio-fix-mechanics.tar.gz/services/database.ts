import { UserAccount, MechanicRecord, Booking } from '../types';
import { DB_KEY_PREFIX, ADMIN_EMAIL, ADMIN_PASSWORD } from '../constants';

interface LoginHistory {
  userId: string;
  timestamp: string;
  location?: { lat: number; lng: number };
  userAgent: string;
}

interface LocationHistory {
  userId: string;
  timestamp: string;
  lat: number;
  lng: number;
  action: string;
}

interface DiagnosticHistory {
  id: string;
  userId: string;
  timestamp: string;
  vehicleType: string;
  faultName: string;
  urgency: string;
  cost: { min: number; max: number };
}

export const DatabaseService = {
  // ============ USER MANAGEMENT ============
  
  getUsers: (): UserAccount[] => {
    const users = localStorage.getItem(`${DB_KEY_PREFIX}_users`);
    return users ? JSON.parse(users) : [];
  },

  saveUser: (user: UserAccount): void => {
    const users = DatabaseService.getUsers();
    const existingIndex = users.findIndex(u => u.email === user.email);
    
    if (existingIndex >= 0) {
      users[existingIndex] = user;
    } else {
      users.push(user);
    }
    
    localStorage.setItem(`${DB_KEY_PREFIX}_users`, JSON.stringify(users));
    DatabaseService.logLocation(user.id, 0, 0, 'registration');
  },

  validateCredentials: (email: string, password: string): UserAccount | null => {
    if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase() && password === ADMIN_PASSWORD) {
      const adminUser: UserAccount = {
        id: 'admin-01',
        name: 'OnWheels Admin',
        email: ADMIN_EMAIL,
        role: 'admin' as any,
        phone: '9666074478'
      };
      DatabaseService.logLogin(adminUser.id);
      return adminUser;
    }

    const users = DatabaseService.getUsers();
    const user = users.find(u => 
      u.email.toLowerCase() === email.toLowerCase() && u.password === password
    );

    if (user) {
      DatabaseService.logLogin(user.id);
      return user;
    }

    return null;
  },

  deleteUser: (userId: string): void => {
    const users = DatabaseService.getUsers();
    const filtered = users.filter(u => u.id !== userId);
    localStorage.setItem(`${DB_KEY_PREFIX}_users`, JSON.stringify(filtered));
    DatabaseService.deleteUserHistory(userId);
  },

  // ============ MECHANIC MANAGEMENT ============

  getMechanics: (): MechanicRecord[] => {
    const mechanics = localStorage.getItem(`${DB_KEY_PREFIX}_mechanics`);
    return mechanics ? JSON.parse(mechanics) : [];
  },

  setMechanics: (mechanics: MechanicRecord[]): void => {
    localStorage.setItem(`${DB_KEY_PREFIX}_mechanics`, JSON.stringify(mechanics));
    window.dispatchEvent(new CustomEvent('sync_db'));
  },

  getMechanicByUserId: (userId: string): MechanicRecord | null => {
    const mechanics = DatabaseService.getMechanics();
    return mechanics.find(m => m.userId === userId) || null;
  },

  addMechanic: (mechanic: MechanicRecord): void => {
    const mechanics = DatabaseService.getMechanics();
    mechanics.push(mechanic);
    DatabaseService.setMechanics(mechanics);
  },

  updateMechanicLocation: (mechanicId: string, lat: number, lng: number): void => {
    const mechanics = DatabaseService.getMechanics();
    const updated = mechanics.map(m => 
      m.mechanicId === mechanicId 
        ? { ...m, lat, lng, lastLocationUpdate: new Date().toISOString() }
        : m
    );
    DatabaseService.setMechanics(updated);
  },

  updateMechanicStatus: (mechanicId: string, status: 'online' | 'offline' | 'busy'): void => {
    const mechanics = DatabaseService.getMechanics();
    const updated = mechanics.map(m => 
      m.mechanicId === mechanicId 
        ? { ...m, status }
        : m
    );
    DatabaseService.setMechanics(updated);
  },

  updateMechanicVerification: (mechanicId: string, isVerified: boolean): void => {
    const mechanics = DatabaseService.getMechanics();
    const updated = mechanics.map(m => 
      m.mechanicId === mechanicId 
        ? { ...m, isVerified, verifiedAt: isVerified ? new Date().toISOString() : undefined }
        : m
    );
    DatabaseService.setMechanics(updated);
  },

  toggleMechanicEnabled: (mechanicId: string): void => {
    const mechanics = DatabaseService.getMechanics();
    const updated = mechanics.map(m => 
      m.mechanicId === mechanicId 
        ? { ...m, isEnabled: !(m as any).isEnabled !== false }
        : m
    );
    DatabaseService.setMechanics(updated);
  },

  deleteMechanic: (mechanicId: string): void => {
    const mechanics = DatabaseService.getMechanics();
    const mechanic = mechanics.find(m => m.mechanicId === mechanicId);
    
    if (mechanic) {
      const filtered = mechanics.filter(m => m.mechanicId !== mechanicId);
      DatabaseService.setMechanics(filtered);
      DatabaseService.deleteUser(mechanic.userId);
      
      const bookings = DatabaseService.getBookings();
      const updatedBookings = bookings.filter(b => b.mechanicId !== mechanicId);
      DatabaseService.setBookings(updatedBookings);
    }
  },

  // ============ BOOKING MANAGEMENT ============

  getBookings: (): Booking[] => {
    const bookings = localStorage.getItem(`${DB_KEY_PREFIX}_bookings`);
    return bookings ? JSON.parse(bookings) : [];
  },

  setBookings: (bookings: Booking[]): void => {
    localStorage.setItem(`${DB_KEY_PREFIX}_bookings`, JSON.stringify(bookings));
    window.dispatchEvent(new CustomEvent('sync_db'));
  },

  // ============ LOGIN HISTORY ============

  logLogin: (userId: string, location?: { lat: number; lng: number }): void => {
    const history = DatabaseService.getLoginHistory();
    const entry: LoginHistory = {
      userId,
      timestamp: new Date().toISOString(),
      location,
      userAgent: navigator.userAgent
    };
    history.push(entry);
    
    const userEntries = history.filter(h => h.userId === userId);
    if (userEntries.length > 100) {
      const filtered = history.filter(h => h.userId !== userId);
      filtered.push(...userEntries.slice(-100));
      localStorage.setItem(`${DB_KEY_PREFIX}_login_history`, JSON.stringify(filtered));
    } else {
      localStorage.setItem(`${DB_KEY_PREFIX}_login_history`, JSON.stringify(history));
    }
  },

  getLoginHistory: (): LoginHistory[] => {
    const history = localStorage.getItem(`${DB_KEY_PREFIX}_login_history`);
    return history ? JSON.parse(history) : [];
  },

  getUserLoginHistory: (userId: string): LoginHistory[] => {
    const history = DatabaseService.getLoginHistory();
    return history.filter(h => h.userId === userId).sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  },

  // ============ LOCATION HISTORY ============

  logLocation: (userId: string, lat: number, lng: number, action: string): void => {
    const history = DatabaseService.getLocationHistory();
    const entry: LocationHistory = {
      userId,
      timestamp: new Date().toISOString(),
      lat,
      lng,
      action
    };
    history.push(entry);
    
    const userEntries = history.filter(h => h.userId === userId);
    if (userEntries.length > 500) {
      const filtered = history.filter(h => h.userId !== userId);
      filtered.push(...userEntries.slice(-500));
      localStorage.setItem(`${DB_KEY_PREFIX}_location_history`, JSON.stringify(filtered));
    } else {
      localStorage.setItem(`${DB_KEY_PREFIX}_location_history`, JSON.stringify(history));
    }
  },

  getLocationHistory: (): LocationHistory[] => {
    const history = localStorage.getItem(`${DB_KEY_PREFIX}_location_history`);
    return history ? JSON.parse(history) : [];
  },

  getUserLocationHistory: (userId: string): LocationHistory[] => {
    const history = DatabaseService.getLocationHistory();
    return history.filter(h => h.userId === userId).sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  },

  // ============ DIAGNOSTIC HISTORY ============

  logDiagnostic: (userId: string, result: any): void => {
    const history = DatabaseService.getDiagnosticHistory();
    const entry: DiagnosticHistory = {
      id: `diag-${Date.now()}`,
      userId,
      timestamp: new Date().toISOString(),
      vehicleType: result.vehicleType,
      faultName: result.faultName,
      urgency: result.urgency,
      cost: {
        min: result.repairEstimate.min,
        max: result.repairEstimate.max
      }
    };
    history.push(entry);
    
    const userEntries = history.filter(h => h.userId === userId);
    if (userEntries.length > 100) {
      const filtered = history.filter(h => h.userId !== userId);
      filtered.push(...userEntries.slice(-100));
      localStorage.setItem(`${DB_KEY_PREFIX}_diagnostic_history`, JSON.stringify(filtered));
    } else {
      localStorage.setItem(`${DB_KEY_PREFIX}_diagnostic_history`, JSON.stringify(history));
    }
  },

  getDiagnosticHistory: (): DiagnosticHistory[] => {
    const history = localStorage.getItem(`${DB_KEY_PREFIX}_diagnostic_history`);
    return history ? JSON.parse(history) : [];
  },

  getUserDiagnosticHistory: (userId: string): DiagnosticHistory[] => {
    const history = DatabaseService.getDiagnosticHistory();
    return history.filter(h => h.userId === userId).sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  },

  // ============ CLEANUP UTILITIES ============

  deleteUserHistory: (userId: string): void => {
    const loginHistory = DatabaseService.getLoginHistory();
    const filteredLogin = loginHistory.filter(h => h.userId !== userId);
    localStorage.setItem(`${DB_KEY_PREFIX}_login_history`, JSON.stringify(filteredLogin));

    const locationHistory = DatabaseService.getLocationHistory();
    const filteredLocation = locationHistory.filter(h => h.userId !== userId);
    localStorage.setItem(`${DB_KEY_PREFIX}_location_history`, JSON.stringify(filteredLocation));

    const diagnosticHistory = DatabaseService.getDiagnosticHistory();
    const filteredDiagnostic = diagnosticHistory.filter(h => h.userId !== userId);
    localStorage.setItem(`${DB_KEY_PREFIX}_diagnostic_history`, JSON.stringify(filteredDiagnostic));
  }
};

// Legacy compatibility
export const DB = {
  getUsers: DatabaseService.getUsers,
  saveUser: DatabaseService.saveUser,
  validate: DatabaseService.validateCredentials,
  getMechanics: DatabaseService.getMechanics,
  setMechanics: DatabaseService.setMechanics,
  getBookings: DatabaseService.getBookings,
  setBookings: DatabaseService.setBookings
};
