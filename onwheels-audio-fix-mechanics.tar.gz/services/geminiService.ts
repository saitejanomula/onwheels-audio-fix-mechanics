
import { GoogleGenAI, Type } from "@google/genai";
import { FileData, InspectionResult } from '../types';

export const runForensicAudit = async (img?: FileData, aud?: FileData): Promise<InspectionResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  const prompt = `Perform a high-precision forensic automotive audit based on visual and/or acoustic evidence provided.
  Analyze symptoms like unusual sounds, smoke, dashboard lights, or fluid leaks.
  Provide a professional diagnostic report in strict JSON format.
  The fault name should be concise (max 10 words).
  Estimates must be in Indian Rupees (INR).`;

  const parts: any[] = [{ text: prompt }];
  
  if (img) {
    parts.push({
      inlineData: {
        data: img.base64,
        mimeType: img.mimeType
      }
    });
  }
  
  if (aud) {
    parts.push({
      inlineData: {
        data: aud.base64,
        mimeType: aud.mimeType
      }
    });
  }

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: { parts },
    config: {
      systemInstruction: "You are OnWheels AI, a world-class automotive forensic specialist. Output ONLY valid JSON according to the schema provided. Be highly accurate with mechanical diagnostics.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          vehicleType: { type: Type.STRING, description: "Type of vehicle (e.g., Sedan, SUV, EV)" },
          faultName: { type: Type.STRING, description: "Concise mechanical fault name" },
          urgency: { type: Type.STRING, enum: ["Low", "Medium", "High", "Critical"] },
          repairEstimate: {
            type: Type.OBJECT,
            properties: {
              min: { type: Type.NUMBER, description: "Minimum repair cost in INR" },
              max: { type: Type.NUMBER, description: "Maximum repair cost in INR" },
              recommendation: { type: Type.STRING, description: "Immediate action recommended" }
            },
            required: ["min", "max", "recommendation"]
          }
        },
        required: ["vehicleType", "faultName", "urgency", "repairEstimate"]
      }
    }
  });

  const rawText = response.text || "";
  try {
    return JSON.parse(rawText) as InspectionResult;
  } catch (e) {
    console.error("Failed to parse Gemini response:", rawText);
    throw new Error("Diagnostic node returned an invalid data structure.");
  }
};
